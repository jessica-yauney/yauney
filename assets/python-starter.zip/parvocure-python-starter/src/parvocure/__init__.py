"""ParvoCure starter package."""
